

<?php $__env->startSection('content'); ?>

<table class="table">
    <thead>
        <tr>
            <th>Id</th>
            <th>Category Name</th>
            <th>Offer Title</th>
            <th>Description</th>
            <th>Image</th>
            <th>Button Text</th>
            <th>Button Link</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>

        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($slider->id); ?></td>
            <td scope="row"><?php echo e($slider->category_name); ?></td>
            <td><?php echo e($slider->offer_title); ?></td>
            <td><?php echo e($slider->description); ?></td>
            <td>
                <img src="<?php echo e(asset('images/sliders/'.$slider->image)); ?>">
            </td>
            <td><?php echo e($slider->button_text); ?></td>
            <td><?php echo e($slider->button_link); ?></td>
            <td>
                <form action="<?php echo e(route('slider.delete',$slider->id)); ?>" method="get">
                    <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-danger">Delete</button>
                </form>

                <a href="<?php echo e(route('slider.edit',$slider->id)); ?>" class="btn btn-success">Edit</a>
            </td>

        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taza fish\resources\views/admin/sliders/index.blade.php ENDPATH**/ ?>
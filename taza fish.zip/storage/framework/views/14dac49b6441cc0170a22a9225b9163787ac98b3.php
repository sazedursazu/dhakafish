

<?php $__env->startSection('content'); ?>

<table class="table">
  <thead>
    <tr>
      
      <th scope="col-1">Id</th>
      <th scope="col-1">Customer Name</th>
      <th scope="col-1">Address</th>
      <th scope="col-1">Phone Number</th>
     
      <th scope="col-1">Grand Total</th>
      <th scope="col-1">Item Count</th>
      <th scope="col-1">Item price</th>
      <th scope="col-1">Action</th>

    </tr>
  </thead>
  <tbody>
  	<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($order->id); ?></td>
      <td><?php echo e($order->shipping_fullname); ?></td>
      <td><?php echo e($order->shipping_address); ?></td>
      <td><?php echo e($order->shipping_phone); ?></td>
     
      <td><?php echo e($order->grand_total); ?> taka</td>
      <td><?php echo e($order->item_count); ?></td>
      <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <td>
      	<?php echo e($item->price); ?>

      </td>  
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <td>
      	<a href="<?php echo e(route('item.delete',$order->id)); ?>" class="btn btn-danger">Delete</a>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </tbody>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taza fish\resources\views/admin/pages/order_details.blade.php ENDPATH**/ ?>
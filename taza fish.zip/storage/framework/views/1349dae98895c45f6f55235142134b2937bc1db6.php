<?php $__env->startSection('content'); ?>
<h1>Add Category</h1>
<form action="<?php echo e(route('categories.store')); ?>" enctype="multipart/form-data" method="POST">
    <?php echo csrf_field(); ?>
<div class="form-group">
  <label for="name">Category Name</label>
  <input type="text" name="name" id="" class="form-control" placeholder="" aria-describedby="helpId">

</div>
<div class="form-group">
    <label for="description">Description</label>
    <input type="text" name="description" id="" class="form-control" placeholder="" aria-describedby="helpId">
  </div>
  <div class="form-group">
    <label for="image">Category Image</label>
    <input type="file" name="image" id="" class="form-control" placeholder="" aria-describedby="helpId">
  </div>
  <div class="form-group">
    <label for="parent_id">Primary Category</label>
   <select name="parent_id" id="" class="form-control">
       <option value="">Select Primary Category</option>
        <?php $__currentLoopData = App\Category::orderBy('name','asc')->where('parent_id',NULL)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </select>
  </div>
  <button type="submit" class="btn btn-success">Save Category</button>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taza fish\resources\views/admin/categories/create.blade.php ENDPATH**/ ?>
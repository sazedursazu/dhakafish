<?php $__env->startSection('content'); ?>
<div class="card">
    <img class="card-img-top" src="holder.js/100x180/" alt="">
    <div class="card-body">
        <h4 class="card-title">Welcome To Your Administrator Panel</h4>
    <a href="<?php echo e(route('products.index')); ?>" class="btn btn-success" target="_blank">Visit Site</a>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taza fish\resources\views/admin/pages/index.blade.php ENDPATH**/ ?>
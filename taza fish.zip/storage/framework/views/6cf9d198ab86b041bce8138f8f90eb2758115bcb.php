<?php $__env->startSection('content'); ?>
<h1>Manage Products</h1>

<table class="table">
    <thead>
        <tr>
            <th>Id</th>
            <th>Title</th>
            <th>Price</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>

        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($product->id); ?></td>
            <td scope="row"><?php echo e($product->title); ?></td>
            <td><?php echo e($product->price); ?></td>
            <td>
                <form action="<?php echo e(route('product.delete',$product->id)); ?>" method="get">
                    <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-danger">Delete</button>
                </form>

            </td>

        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taza fish\resources\views/admin/pages/manage_products.blade.php ENDPATH**/ ?>
<?php $__env->startSection('slider'); ?>

<div id="carouselId" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
        <li data-target="#carouselId" data-slide-to="0" class="active"></li>
        <li data-target="#carouselId" data-slide-to="1"></li>
        <li data-target="#carouselId" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner" role="listbox">

        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="carousel-item <?php echo e($loop->index==0 ? 'active':''); ?>">

                            <div class="hero__item set-bg" data-setbg="<?php echo e(asset('/images/sliders/'.$slider->image)); ?>">
                        <div class="hero__text ">
                            <div class="badge badge-warning mb-4 p-4">
                                <span><?php echo e($slider->category_name); ?></span>
                            <h2><?php echo e($slider->offer_title); ?> <br />100% Fresh</h2>
                            <p><?php echo e($slider->description); ?></p>
                            </div>
                        </div>
                        </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

       
       
    </div>
    <a class="carousel-control-prev" href="#carouselId" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselId" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div>





<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

 <!-- Categories Section Begin -->
   
    <!-- Categories Section End -->

    <!-- Featured Section Begin -->
    <section class="featured spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title">
                        <h2>Featured Product</h2>
                    </div>

                </div>
            </div>
            <div class="row featured__filter">

                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="col-12 col-sm-8 col-md-6 col-lg-4 mb-4">
                      <div class="card">

                        <?php $i=1; ?>

                        <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($i>0): ?>
                        <img class="card-img" src="<?php echo e(asset('images/'.$image->image)); ?>" alt="Vans" style="height: 300px">
                        <?php endif; ?>

                        <?php $i--; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                        <div class="card-body">
                          <h4 class="card-title"><?php echo e($product->title); ?></h4>
                        
                          <div class="buy d-flex justify-content-between align-items-center">
                            <div class="price text-success"><h5 class="mt-4"><?php echo e($product->price); ?> Taka</h5></div>
                             <a href="<?php echo e(route('cart.add',$product->id)); ?>" class="btn btn-warning mt-3">Add to Cart</a>
                          </div>
                        </div>
                      </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
             <div class="pagination">
                    <?php echo e($products->links()); ?>

                </div>
        </div>
    </section>
    <!-- Featured Section End -->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taza fish\resources\views/frontend/pages/index.blade.php ENDPATH**/ ?>
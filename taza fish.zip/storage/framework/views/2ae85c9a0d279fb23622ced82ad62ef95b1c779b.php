<?php $__env->startSection('content'); ?>
<h1>Edit Product</h1>

<form action="<?php echo e(route('product.update',$product->id)); ?>" method="post" enctype="multipart/form-data">
	<?php echo csrf_field(); ?>
	<div class="form-group">
		<label for="title">Product Title</label>
		<input type="text" name="title" class="form-control" value="<?php echo e($product->title); ?>">
	</div>
	<div class="form-group">
		<label for="description">Product Description</label>
		<input type="text" name="description" class="form-control" value="<?php echo e($product->description); ?>">
	</div>
	<div class="form-group">
		<label for="weight">Product Weight</label>
		<input type="text" name="weight" class="form-control" value="<?php echo e($product->weight); ?>">
	</div>
	<div class="form-group">
		<label for="price">Product Price</label>
		<input type="number" name="price" class="form-control" value="<?php echo e($product->price); ?>">
	</div>
	<div class="form-group">
		<label for="offer_price">Product Offer_Price</label>
		<input type="number" name="offer_price" class="form-control" value="<?php echo e($product->offer_price); ?>">
	</div>
	<div class="form-group">
		<label for="category_id">Product Category Id</label>
		<input type="number" name="category_id" class="form-control" value="<?php echo e($product->category_id); ?>">
	</div>
	<div class="form-group">
		<label for="admin_id">Product Admin Id</label>
		<input type="number" name="admin_id" class="form-control" value="<?php echo e($product->admin_id); ?>">
	</div>
	<div class="form-group">
		<label for="image">Product Image</label>
		<input type="file" name="image" class="form-control">
	</div>

	<button type="submit" class="btn btn-success">Update Product</button>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taza fish\resources\views/admin/pages/edit.blade.php ENDPATH**/ ?>
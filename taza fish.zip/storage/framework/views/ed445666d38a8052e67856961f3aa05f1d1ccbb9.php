

<?php $__env->startSection('content'); ?>
<h1>Edit Category</h1>
 <form action="<?php echo e(route('categories.update',$category->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                <label for="name">Category Name</label>
                <input type="text" name="name" id="" class="form-control" placeholder="" aria-describedby="helpId" value="<?php echo e($category->name); ?>">
                </div>
                <div class="form-group">
                  <label for="description">Description</label>
                  <textarea class="form-control" name="description" id="" cols="30" rows="10"><?php echo e($category->description); ?></textarea>

                </div>

                  <div class="form-group">
                    <label for="parent_id">Select Category</label>
                    <select name="parent_id" class="form-control" id="">
                        <option value="">Select Primary Category</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <option value="<?php echo e($cat->id); ?>" <?php echo e($cat->id==$category->parent_id? 'selected':''); ?>>
                        <?php echo e($category->name); ?>

                        </option>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                  </div>
                  <div class="form-group">
                    <label for="oldimage">Old Category Image</label><br>
                    <img src="<?php echo e(asset('images/categories/'.$category->image)); ?>" width="200"><br><br>
                     <input type="file" name="image" id="image" class="form-control" placeholder="" aria-describedby="helpId">
                  </div>
                  <div class="form-group">
                    <input type="submit" value="Update Category" id="" class="form-control btn btn-primary" placeholder="" aria-describedby="helpId">
                  </div>
             </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taza fish\resources\views/admin/categories/edit.blade.php ENDPATH**/ ?>
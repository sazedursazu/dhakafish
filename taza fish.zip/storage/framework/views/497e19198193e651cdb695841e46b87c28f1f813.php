





<?php $__env->startSection('slider'); ?>

 <!-- Categories Section Begin -->
   
    <!-- Categories Section End -->

    <!-- Featured Section Begin -->
    <section class="featured spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title">
                        <h2>Search Product For <span class="badge badge-info">" <?php echo e($search); ?> "</span ></h2>
                    </div>

                </div>
            </div>
            <div class="row featured__filter">

                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="col-12 col-sm-8 col-md-6 col-lg-3">
                      <div class="card">

                        <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img class="card-img" src="<?php echo e(asset('images/'.$image->image)); ?>" alt="Vans" style="height: 300px">

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                        <div class="card-body">
                          <h4 class="card-title"><?php echo e($product->title); ?></h4>
                        
                          <div class="buy d-flex justify-content-between align-items-center">
                            <div class="price text-success"><h5 class="mt-4"><?php echo e($product->price); ?> Taka</h5></div>
                             <a href="<?php echo e(route('cart.add',$product->id)); ?>" class="btn btn-warning mt-3">Add to Cart</a>
                          </div>
                        </div>
                      </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
             <div class="pagination">
                    <?php echo e($products->links()); ?>

                </div>
        </div>
    </section>
    <!-- Featured Section End -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taza fish\resources\views/frontend/pages/search.blade.php ENDPATH**/ ?>
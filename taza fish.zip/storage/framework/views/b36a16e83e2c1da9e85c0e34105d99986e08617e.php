<?php $__env->startSection('content'); ?>
<h1>Manage Category</h1>
<table class="table">
    <thead>
        <tr>
            <th>Id</th>
            <th>Category Name</th>
            <th>Parent Name</th>
            <th>Category Image</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>

        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td scope="row"><?php echo e($category->id); ?></td>
            <td><?php echo e($category->name); ?></td>
            <td>
                <?php if($category->parent_id==NULL): ?>
                Primary Category

                <?php else: ?>
                <?php echo e($category->parent->name); ?>


                <?php endif; ?>
            </td>
            <td>
                <img src="<?php echo e(asset('images/categories/'.$category->image)); ?>" alt="" width="200">
            </td>
            <td>
                <form action="<?php echo e(route('categories.edit',$category->id)); ?>" method="get">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-primary">Edit</button>
                </form>
                <a href="<?php echo e(route('categories.delete',$category->id)); ?>" class="btn btn-danger mt-4">Delete</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taza fish\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>
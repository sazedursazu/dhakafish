

 
 
<?php $__env->startSection('slider'); ?>
 
 <h1>Checkout</h1>
    <form action="<?php echo e(route('checkout.store')); ?>" method="post">
    	<?php echo csrf_field(); ?>
    	<div class="form-group">
    		<label for="shipping_fullname">Shipping FullName</label>
    		<input type="text" name="shipping_fullname" class="form-control">
    	</div>
    	<div class="form-group">
    		<label for="shipping_address">Shipping Address</label>
    		<input type="text" name="shipping_address" class="form-control">
    	</div>
    	<div class="form-group">
    		<label for="shipping_phone">Shipping Mobile Number</label>
    		<input type="phone" name="shipping_phone" class="form-control">
    	</div>
    	<div class="form-group">
    		
    	<button type="submit" class="btn btn-success">Place Order</button>
    	</div>
    </form>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taza fish\resources\views/carts/checkout.blade.php ENDPATH**/ ?>
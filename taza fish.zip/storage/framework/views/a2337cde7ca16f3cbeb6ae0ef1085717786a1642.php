

<?php $__env->startSection('slider'); ?>
	<h1>Order Items Table</h1>
	 <table class="table">
  <thead>
    <tr>
      
      <th scope="col-">Id</th>
      <th scope="col">Customer Name</th>
      <th scope="col">Address</th>
      <th scope="col">Phone Number</th>
      <th scope="col">Order Number</th>
      <th scope="col">Grand Total</th>
      <th scope="col">Item Count</th>
      <th scope="col">Item price</th>
      <th scope="col">Action</th>

    </tr>
  </thead>
  <tbody>
  	<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($order->id); ?></td>
      <td><?php echo e($order->shipping_fullname); ?></td>
      <td><?php echo e($order->shipping_address); ?></td>
      <td><?php echo e($order->shipping_phone); ?></td>
      <td><?php echo e($order->order_number); ?></td>
      <td><?php echo e($order->grand_total); ?> taka</td>
      <td><?php echo e($order->item_count); ?></td>
      <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <td>
      	<?php echo e($item->price); ?>

      </td>  
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <td>
      	<a href="<?php echo e(route('item.delete',$order->id)); ?>" class="btn btn-danger">Delete</a>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </tbody>
</table>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taza fish\resources\views/carts/item.blade.php ENDPATH**/ ?>